# M2_Summative_Assessment
Dulcis Maison is a small, family-owned pastry business founded in 2012, known for its high-quality pastries. 
